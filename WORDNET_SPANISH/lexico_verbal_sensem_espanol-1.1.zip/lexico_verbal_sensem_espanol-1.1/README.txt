The Spanish lexicon SenSem has been created as part of the Spanish SenSem Databank. Work on the Databank started in the year 2004 and continues in 2014. All the projects contributing to the Databank’s creation have been funded by the Spanish Government through a variety of grants.

In its 1.1 version, this resource contains the description of almost 1,300 verbs that, in turn, correspond to the 250 most frequent verbs in Spanish. The frequency of these verbs was retrieved from a quantitative analysis of a journalistic corpus of around 13 million words.

The description of verbs features information that can be divided into two groups. In the first place, the data that have been codified manually: the definition, the synset of WordNet (versions 1.5, 1.6 and 2.0), the Aktionsart and the number of arguments and their semantic functions.

In the second place, one will find the information that has been automatically extracted from the Spanish SenSem Corpus (which mainly includes journalistic texts and a relatively small portion of literary texts): frequency of the verb in the Corpus (differentiating between the two registers), subcategorization patterns, their frequency and examples. This information is associated to around one thousand verbs in the lexicon, those represented in our Corpus.

Subcategorization patterns are described at four different levels. In the first, the most abstract level, general patterns are codified. In these patterns, certain syntactic categories have been merged (as in the case of NP and pronoun or infinitive clause) and the order of constituents has been reorganized so as to display the unmarked Spanish word order (subject, direct object, indirect object, prepositional object, other objects).

In the second level, the semantics of the construction is specified for every pattern by differentiating between two large types of constructions: logical subject topicalization or logical subject detopicalization.

In the third level, syntactic categories are specified following a great degree of granularity (proper noun, interrogative pronoun, etc.).

Lastly, the actual order of the constituents that make up the subcategorization pattern is presented. It is pointed out whether this order follows or not the neutral Spanish word order. At the same time, it is specified whether the sentences have any other non-argumental constituents (i.e. adjuncts).

The lexicon of the Spanish SenSem Databank contains a great amount of information that is especially interesting and useful in several fields: language teaching/acquisition, lexicography and natural language processing (NLP). With regard to language teaching/acquisition, the information about the verbs and their syntax constitutes, undoubtedly, a very valuable resource. In the area of lexicography, the information about subcategorization patterns may be used in order to improve the description of the verbal lexicographic entries. Lastly, in the highly active field of NLP, the information that is included in the verbal subcategorization patterns may be used to provide guidance for automatic syntactic analyses and to improve results in this field. It can also be used to improve the results of the automatic disambiguation of meanings.

One can search the lexicon online through the search engine available on the website: http://grial.uab.es/sensem/corpus. On this webpage, more specific documentation can be accessed, such as the definition of the terms used and their equivalence in other projects. All the publications related to this project can be consulted at http://grial.uab.es/publicacions.php.

